package org.owntracks.android.support;

import android.os.Message;

public interface StaticHandlerInterface {
	void handleHandlerMessage(Message msg);
}
